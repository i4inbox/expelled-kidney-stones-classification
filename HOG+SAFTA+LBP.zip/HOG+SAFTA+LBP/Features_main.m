clear all;
clc;
imagespath=imageSet('C:\Workstation\Thesis\Experiments\Processed-Dataset','recursive');
imagecount=1;
s = size(imagespath,4);
for i=1 : size(imagespath,2)
    
    m=size(imagespath(i).ImageLocation,2);
    temp=imagespath(i).ImageLocation;
     for j=1 :  m
        v{imagecount,1}=temp{j};
         X = [' Labeling ',num2str(i),'/',num2str(size(imagespath,2)),'/',num2str(j)];
        disp(X)
            if(~isempty(strfind(temp{j},'111111')))
                v{imagecount,2}='X';
            elseif (~isempty(strfind(temp{j},'222222')))
                v{imagecount,2}='C';
            elseif (~isempty(strfind(temp{j},'333333')))
                v{imagecount,2}='H';
            elseif ( ~isempty(strfind(temp{j},'444444')))
                v{imagecount,2}='G';
            elseif (~isempty(strfind(temp{j},'555555')))
                v{imagecount,2}='R';
            elseif (~isempty(strfind(temp{j},'666666')))
                v{imagecount,2}='S';
            elseif (~isempty(strfind(temp{j},'777777')))
                v{imagecount,2}='U';
            elseif (~isempty(strfind(temp{j},'888888')))
                v{imagecount,2}='O';
                else
                  v{imagecount,2}='W'; 
            end
            img=imread(v{imagecount,1}); 
            img=rgb2gray(img); %Convert to GrayScale Image
            img=histeq(img);%Histogram 
            %img = imsharpen(img); Sharp Image
            
            img=single(img);
         
             img=imresize(img,[64,64]);
             featureVector=extractHOGFeatures(img); %Hog Feature Extractions
             featureVector1=sfta(img,4); %Texture Feature Extractions
             featureVector2=extractLBPFeatures(img); %Local Binary Pattern (LBP) Feature Extractions
             

            feature{imagecount,1}=featureVector(1,:);
            feature1{imagecount,1}=featureVector1(1,:);
            feature2{imagecount,1}=featureVector2(1,:);
        imagecount=imagecount+1;
     end
end

for i=1:length(feature)
     X = [' First Features alighing ',num2str(i),'/',num2str(length(feature))];
  disp(X)
    ftemp=double(feature{i});
    i;
    FV(i,:)=ftemp;  
    
end

for i=1:length(feature1)
    X = [' Second Features alighing ',num2str(i),'/',num2str(length(feature1))];
  disp(X)
    ftemp1=double(feature1{i});
    
    FV1(i,:)=ftemp1;  
end
for i=1:length(feature2)
    X = [' fourth for ',num2str(i),'/',num2str(length(feature2))];
  disp(X)
    ftemp2=double(feature2{i});
    
    FV2(i,:)=ftemp2;  
end
X=v(:,2);

  % Component Analysis Score from feature vactors
 [pc,score] = princomp(FV);
 [pc1,score1] = princomp(FV1);
 [pc2,score2] = princomp(FV2); 


  red_dim_Hog = score(:,1:100);
  red_dim_Sfta = score1(:,1:21);
  red_dim_LBP = score2(:,1:40);
  red_dim = horzcat(red_dim_Sfta,red_dim_Hog, red_dim_LBP );
  red_dim(:,size(red_dim,2)+1)=cell2mat(X);

  
