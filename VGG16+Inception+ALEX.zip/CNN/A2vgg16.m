clear all;
clc;
close all;

imds = imageDatastore('C:\Workstation\Thesis\Experiments\Processed-Dataset', ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');

numTrainImages = numel(imds.Labels);

net = vgg16();
 
net.Layers
analyzeNetwork(net)

inputSize = net.Layers(1).InputSize;


augmentedTrainingSet = augmentedImageDatastore(inputSize(1:2),imds);

layer = 'fc7';
vgg16featuresTrain = activations(net,augmentedTrainingSet,layer,'OutputAs','rows');

YTrain = imds.Labels;

save('vgg16featuresTrain.mat','vgg16featuresTrain');