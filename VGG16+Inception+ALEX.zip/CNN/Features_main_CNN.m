clear all;
clc;
imagespath=imageSet('/Volumes/Development/Workstation/Thesis/Experiments/Processed-Dataset','recursive');
imagecount=1;
s = size(imagespath,4);
for i=1 : size(imagespath,2)
    
    m=size(imagespath(i).ImageLocation,2);
    temp=imagespath(i).ImageLocation;
     for j=1 :  m
        v{imagecount,1}=temp{j};      
            if(~isempty(strfind(temp{j},'111111')))
                v{imagecount,2}='X';
            elseif (~isempty(strfind(temp{j},'222222')))
                v{imagecount,2}='C';
            elseif (~isempty(strfind(temp{j},'333333')))
                v{imagecount,2}='H';
            elseif ( ~isempty(strfind(temp{j},'444444')))
                v{imagecount,2}='G';
            elseif (~isempty(strfind(temp{j},'555555')))
                v{imagecount,2}='R';
            elseif (~isempty(strfind(temp{j},'666666')))
                v{imagecount,2}='S';
            elseif (~isempty(strfind(temp{j},'777777')))
                v{imagecount,2}='U';
            elseif (~isempty(strfind(temp{j},'888888')))
                v{imagecount,2}='O';
                else
                  v{imagecount,2}='W'; 
            end
        imagecount=imagecount+1;
     end
end
X=v(:,2);
%============================AlexNet Features ============
load('AlexfeaturesTrain.mat');
AlexfeaturesTrain=double(AlexfeaturesTrain);
load('InceptionfeaturesTrain.mat');
InceptionfeaturesTrain=double(InceptionfeaturesTrain);
load('vgg16featuresTrain.mat');
vgg16featuresTrain=double(vgg16featuresTrain);
%===================================================
  % Component Analysis Score from feature vactors
 [pc,score] = princomp(InceptionfeaturesTrain);
 [pc1,score1] = princomp(vgg16featuresTrain);
 [pc2,score2] = princomp(AlexfeaturesTrain); 
 %[pc3,score3]=   princomp(AlexfeaturesTrain);

  red_dim_Inseption = score(:,1:40);
  red_dim_Vgg16 = score1(:,1:40);
  red_dim_Alex = score2(:,1:40);
 
%   , red_dim_Alex
  red_dim = horzcat(red_dim_Inseption,red_dim_Vgg16, red_dim_Alex );
  red_dim(:,size(red_dim,2)+1)=cell2mat(X);

  
