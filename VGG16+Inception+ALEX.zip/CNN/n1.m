
I=cjdata.image ;
imshow(I);
% I2=double(I);
I8=uint8(ones(10,10,'uint16'));
figure(2), imshow(I8);